# SKALA증권 세무상담 HelpDesk AI

Spring AI 기반 금융소득 세무 상담 API. 2026년 귀속 이자·배당소득의
종합과세 여부를 판정하고 예상 세액을 산출한다.

## 실행

```bash
export OPENAI_API_KEY_SKALA1=sk-...
./gradlew bootRun                                # 기본 8080
./gradlew bootRun --args='--server.port=8099'    # 포트 변경
```

서버가 뜨면 세법 문서를 색인한다. 인메모리 벡터 스토어라 재시작할 때마다 다시 해야 한다.

```bash
curl -u admin:admin -X POST localhost:8080/admin/ingest
open http://localhost:8080/console.html
```

## 계정

| 계정 | 비밀번호 | 담당 분기 |
|---|---|---|
| `antman` | `pass1` | 분리과세 종결 — `calculateTax` 미호출 |
| `isabu` | `pass2` | ISA 비과세·분리과세분 제외 |
| `jonber` | `pass3` | 비교과세 ①<② |
| `richman` | `pass4` | 비교과세 ①>② · Gross-up 전액 |
| `americano` | `pass5` | 해외배당 — Gross-up 대상 0 |
| `admin` | `admin` | 색인·승인 (상담 API 접근 불가) |

## 구조

```
chat/       QueryRouter      질문을 5개 경로로 분류 (규칙 → 모델 2단)
            TaxDeskService   경로별로 RAG·Tool 을 부르고 응답을 조립
            AmountParser     고객 문장에서 금액을 규칙으로 추출
            ConversationState 대화별 계산 입력값 보관 (미상과 0 을 구분)
tools/      AccountIncomeTools  소유자 조건을 쿼리에 넣어 본인 것만 조회
            TaxCalcTools        판정·세액·역산. steps[] 로 전개를 남긴다
            ProductApplicationTools  절세상품 자격확인 접수 (PENDING 까지만)
advisor/    AuditAdvisor(0) SafetyAdvisor(100) TokenMeterAdvisor(900)
rag/        IngestService    조문 헤딩 경계로 청킹, 조문 메타를 청크에 남긴다
config/     AiConfig         ChatClient 3종 · 시스템 프롬프트
            TaxDeskProperties 세율표·기준금액 (세법이 바뀌면 여기만 바뀐다)
web/        ChatController   대화방 키에 소유자를 박는다 {계정}:{방}
resources/tax-docs/   RAG 원문 9종
resources/static/     API 콘솔
```

## 설계 원칙

- **세액은 도구가 계산하고 모델은 인용만 한다.** 모델이 산수를 하면 검증할 수 없다.
- **도구 호출 순서를 코드가 정한다.** 조회 → 판정 → 종합과세일 때만 계산 (소득세법 §62).
- **소유자 조건은 쿼리에 넣는다.** 도구 시그니처에 타인 ID 를 넣을 자리를 두지 않는다.
- **거절은 규칙에서 끝낸다.** 모델을 부르지 않으므로 토큰이 0 이다.
- **모르는 값은 계산하지 않고 되묻는다.** 0 으로 놓고 계산하면 틀린 답이 확신 있게 나간다.

## 세법 상수

`application.properties` 에 있다. 코드에는 세율이 없다.

```
taxdesk.threshold-amount=20000000    종합과세기준금액 (소득세법 §14③6호)
taxdesk.gross-up-rate=0.10           배당가산율 (§17③, 2024년 11%→10%)
taxdesk.separate-tax-rate=0.14       원천징수세율 (§129①)
taxdesk.brackets[n]                  누진세율표 (§55)
```

## 테스트

```bash
./gradlew test
```
